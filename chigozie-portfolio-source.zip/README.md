# Chigozie Nkwopara — Portfolio

Business analysis, healthcare and operations analytics portfolio.

Live site: https://chigozie-nkwopara.netlify.app/

## Projects

- Readmissions analysis: https://github.com/Ghenomenon/readmissions-case-study
- Power BI report: https://github.com/Ghenomenon/readmissions-powerbi
- USAID supply chain: https://github.com/Ghenomenon/usaid-supply-chain-analytics
- Stockroom analytics: https://github.com/Ghenomenon/stockroom-analytics-powerbi

## Deploy

Static HTML, CSS and JavaScript. No build command required. The Netlify publish directory is the repository root. Existing clean routes are configured in _redirects. See DEPLOYMENT.md. GitHub publication does not itself replace the existing Netlify deployment.

The healthcare explorer contains aggregate capacity results only. Its Power BI image is an independent layout preview. Native Power BI service embedding requires a separate published report URL.
